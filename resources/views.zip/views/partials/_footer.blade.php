<hr>

<p class="text-center">CryptoPlus Admin Dashboard - All Rights Reserved</p>